<?php

return array(
	'Adminer.meta.title'	=> "数据库管理工具",
	'Adminer.meta.desc'		=> "Adminer 是一款全功能的数据库管理工具,类似phpMyAdmin，相比而言更轻量强大。<br/><br/>支持管理的数据库：MySQL, PostgreSQL, SQLite, MS SQL, Oracle, SimpleDB, Elasticsearch, MongoDB, Firebird<br/>由于安全要求比较高，此插件仅限管理员可以使用"
);