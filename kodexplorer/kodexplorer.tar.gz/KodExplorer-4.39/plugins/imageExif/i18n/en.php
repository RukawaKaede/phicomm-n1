<?php
return array(
	'imageExif.meta.name' 		=> 'Image EXIF',
	'imageExif.meta.title' 		=> 'Image EXIF Get',
	'imageExif.meta.desc' 		=> 'Picture EXIF access; camera phone to take pictures automatically correct direction',
	'imageExif.Config.missLib' 	=> "Lack php exif extensions, try again after installation"
);